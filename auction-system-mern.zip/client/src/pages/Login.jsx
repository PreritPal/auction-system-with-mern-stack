import { useState } from 'react'
import { api } from '../lib/api'

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')

  async function submit(e) {
    e.preventDefault()
    try {
      const res = await api.post('/auth/login', { email, password })
      onLogin(res.data.token)
    } catch (e) {
      setErr(e.response?.data?.error || 'Login failed')
    }
  }

  return (
    <form onSubmit={submit} className="card max-w-md">
      <h2 className="text-xl font-semibold mb-4">Login</h2>
      {err && <div className="text-red-600 text-sm mb-2">{err}</div>}
      <input className="input mb-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input className="input mb-2" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button className="btn">Login</button>
    </form>
  )
}
