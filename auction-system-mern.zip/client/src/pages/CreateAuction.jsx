import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../lib/api'

export default function CreateAuction({ user }) {
  const nav = useNavigate()
  const [f, setF] = useState({
    title: '',
    description: '',
    imageUrl: '',
    category: 'general',
    startingPrice: 100,
    endsAt: new Date(Date.now() + 24*60*60*1000).toISOString().slice(0,16) // input[type=datetime-local]
  })

  if (!user || (user.role !== 'seller' && user.role !== 'admin'))
    return <div className="card">Only sellers can create auctions.</div>

  function change(e) {
    setF({ ...f, [e.target.name]: e.target.value })
  }

  async function submit(e) {
    e.preventDefault()
    const payload = { ...f, endsAt: new Date(f.endsAt).toISOString() }
    const res = await api.post('/auctions', payload)
    nav(`/auctions/${res.data._id}`)
  }

  return (
    <form onSubmit={submit} className="card max-w-2xl">
      <h2 className="text-xl font-semibold mb-4">Create Auction</h2>
      <div className="grid md:grid-cols-2 gap-4">
        <div><label className="text-sm">Title</label><input className="input" name="title" value={f.title} onChange={change} /></div>
        <div><label className="text-sm">Category</label><input className="input" name="category" value={f.category} onChange={change} /></div>
        <div className="md:col-span-2"><label className="text-sm">Description</label><textarea className="input" name="description" rows="4" value={f.description} onChange={change} /></div>
        <div className="md:col-span-2"><label className="text-sm">Image URL</label><input className="input" name="imageUrl" value={f.imageUrl} onChange={change} placeholder="https://..." /></div>
        <div><label className="text-sm">Starting Price</label><input className="input" type="number" name="startingPrice" value={f.startingPrice} onChange={change} /></div>
        <div><label className="text-sm">Ends At</label><input className="input" type="datetime-local" name="endsAt" value={f.endsAt} onChange={change} /></div>
      </div>
      <button className="btn mt-4">Create</button>
    </form>
  )
}
