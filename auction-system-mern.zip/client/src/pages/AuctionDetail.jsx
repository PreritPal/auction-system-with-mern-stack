import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { api } from '../lib/api'
import io from 'socket.io-client'

const socket = io('/', { path: '/socket.io' })

export default function AuctionDetail({ user }) {
  const { id } = useParams()
  const [a, setA] = useState(null)
  const [amount, setAmount] = useState('')

  useEffect(() => {
    api.get(`/auctions/${id}`).then(res => setA(res.data))
  }, [id])

  useEffect(() => {
    socket.on('bid:update', (msg) => {
      if (msg.auctionId === id) {
        setA(prev => prev ? { ...prev, currentPrice: msg.highestBid } : prev)
      }
    })
    socket.on('auction:closed', (msg) => {
      if (msg.auctionId === id) setA(prev => prev ? { ...prev, status: 'closed' } : prev)
    })
    return () => {
      socket.off('bid:update')
      socket.off('auction:closed')
    }
  }, [id])

  if (!a) return <div>Loading...</div>

  async function placeBid(e) {
    e.preventDefault()
    if (!user) return alert('Login first')
    const token = localStorage.getItem('auction_token')
    socket.emit('bid:place', { auctionId: id, amount: Number(amount), token })
    setAmount('')
  }

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="card">
        <img src={a.imageUrl || 'https://via.placeholder.com/800x450?text=Auction'} alt="" className="w-full rounded-xl mb-3" />
        <h1 className="text-2xl font-bold mb-2">{a.title}</h1>
        <p className="mb-2">{a.description}</p>
        <div className="text-sm text-gray-600">Seller: {a.seller?.name}</div>
        <div className="text-sm text-gray-600">Ends: {new Date(a.endsAt).toLocaleString()}</div>
        <div className="mt-3 text-lg font-semibold">Current Price: ₹{a.currentPrice}</div>
        <div className="mt-1 text-xs">Status: <span className="font-mono">{a.status}</span></div>
      </div>
      <div className="card">
        <form onSubmit={placeBid} className="space-y-3">
          <label className="block text-sm font-medium">Your Bid</label>
          <input className="input" type="number" min="1" step="1" value={amount} onChange={e => setAmount(e.target.value)} />
          <button className="btn">Place Bid</button>
        </form>
        <div className="mt-6">
          <h3 className="font-semibold mb-2">Bids</h3>
          <ul className="list-disc pl-5 text-sm text-gray-600">
            {a.bids?.slice().reverse().map((b, idx) => (
              <li key={idx}>₹{b.amount} at {new Date(b.createdAt).toLocaleString()}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  )
}
