import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../lib/api'

export default function Auctions() {
  const [items, setItems] = useState([])
  const [q, setQ] = useState('')

  useEffect(() => {
    api.get('/auctions').then(res => setItems(res.data.items))
  }, [])

  function search(e) {
    e.preventDefault()
    api.get('/auctions', { params: { q } }).then(res => setItems(res.data.items))
  }

  return (
    <div>
      <form onSubmit={search} className="flex gap-2 mb-4">
        <input className="input" placeholder="Search auctions..." value={q} onChange={e => setQ(e.target.value)} />
        <button className="btn">Search</button>
      </form>
      <div className="grid md:grid-cols-3 gap-4">
        {items.map(a => (
          <Link key={a._id} to={`/auctions/${a._id}`} className="card">
            <img src={a.imageUrl || 'https://via.placeholder.com/640x360?text=Auction'} alt="" className="w-full h-40 object-cover rounded-xl mb-3" />
            <div className="font-semibold">{a.title}</div>
            <div className="text-sm text-gray-600">Current: ₹{a.currentPrice}</div>
            <div className="text-xs text-gray-500">Ends: {new Date(a.endsAt).toLocaleString()}</div>
          </Link>
        ))}
      </div>
    </div>
  )
}
