export default function Profile({ user }) {
  if (!user) return <div className="card">Login to view your profile.</div>
  return (
    <div className="card max-w-xl">
      <h2 className="text-xl font-semibold mb-4">Profile</h2>
      <div><span className="font-medium">Name:</span> {user.name}</div>
      <div><span className="font-medium">Email:</span> {user.email}</div>
      <div><span className="font-medium">Role:</span> {user.role}</div>
      <p className="text-sm text-gray-600 mt-3">Ask your instructor or set directly in DB to become a seller/admin.</p>
    </div>
  )
}
