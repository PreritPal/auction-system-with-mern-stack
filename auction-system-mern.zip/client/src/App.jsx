import { useEffect, useState } from 'react'
import { Routes, Route, Link, useNavigate } from 'react-router-dom'
import { api, setAuthToken } from './lib/api'
import { saveToken, loadToken, clearToken } from './lib/auth'
import Auctions from './pages/Auctions'
import AuctionDetail from './pages/AuctionDetail'
import CreateAuction from './pages/CreateAuction'
import Login from './pages/Login'
import Register from './pages/Register'
import Profile from './pages/Profile'

export default function App() {
  const [user, setUser] = useState(null)
  const navigate = useNavigate()

  useEffect(() => {
    const token = loadToken()
    if (token) {
      setAuthToken(token)
      api.get('/me').then(res => setUser(res.data.user)).catch(() => {})
    }
  }, [])

  function logout() {
    clearToken()
    setAuthToken(null)
    setUser(null)
    navigate('/')
  }

  return (
    <div>
      <header className="border-b bg-white">
        <div className="container flex items-center justify-between py-4">
          <Link to="/" className="text-xl font-semibold">Auction System</Link>
          <nav className="flex gap-4">
            <Link to="/" className="btn">Home</Link>
            {user?.role === 'seller' && <Link to="/create" className="btn">Create Auction</Link>}
            {user ? (
              <>
                <Link to="/profile" className="btn">{user.name}</Link>
                <button onClick={logout} className="btn">Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn">Login</Link>
                <Link to="/register" className="btn">Register</Link>
              </>
            )}
          </nav>
        </div>
      </header>
      <main className="container py-6">
        <Routes>
          <Route path="/" element={<Auctions />} />
          <Route path="/auctions/:id" element={<AuctionDetail user={user} />} />
          <Route path="/create" element={<CreateAuction user={user} />} />
          <Route path="/login" element={<Login onLogin={(token) => {
            saveToken(token); setAuthToken(token); api.get('/me').then(r => setUser(r.data.user)); navigate('/')
          }} />} />
          <Route path="/register" element={<Register onRegister={(token) => {
            saveToken(token); setAuthToken(token); api.get('/me').then(r => setUser(r.data.user)); navigate('/')
          }} />} />
          <Route path="/profile" element={<Profile user={user} />} />
        </Routes>
      </main>
    </div>
  )
}
