import { Router } from "express";
import { body, validationResult } from "express-validator";
import Auction from "../models/Auction.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import jwt from "jsonwebtoken";

let ioRef = null;
export const registerBidSocket = (io) => {
  ioRef = io;
  io.on("connection", (socket) => {
    socket.on("bid:place", async ({ auctionId, amount, token }) => {
      try {
        const payload = jwt.verify(token, process.env.JWT_SECRET);
        const userId = payload.id;
        const auction = await Auction.findById(auctionId);
        if (!auction || auction.status !== "active") return;
        const min = Math.max(auction.currentPrice || auction.startingPrice, auction.startingPrice);
        if (amount <= min) return;
        auction.currentPrice = amount;
        auction.bids.push({ user: userId, amount });
        await auction.save();
        io.emit("bid:update", {
          auctionId,
          highestBid: auction.currentPrice,
          highestBidder: userId,
          bidCount: auction.bids.length
        });
      } catch (e) {
        // ignore
      }
    });
  });
};

const router = Router();

// List auctions with simple filters
router.get("/", async (req, res) => {
  const { q, status, category, page = 1, limit = 12 } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (category) filter.category = category;
  if (q) filter.title = { $regex: q, $options: "i" };
  const skip = (Number(page) - 1) * Number(limit);
  const [items, total] = await Promise.all([
    Auction.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)).populate("seller", "name"),
    Auction.countDocuments(filter)
  ]);
  res.json({ items, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
});

router.get("/:id", async (req, res) => {
  const item = await Auction.findById(req.params.id).populate("seller", "name");
  if (!item) return res.status(404).json({ error: "Not found" });
  res.json(item);
});

router.post(
  "/",
  requireAuth,
  requireRole(["seller", "admin"]),
  body("title").isLength({ min: 3 }),
  body("startingPrice").isFloat({ gt: 0 }),
  body("endsAt").isISO8601(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const payload = {
      title: req.body.title,
      description: req.body.description || "",
      imageUrl: req.body.imageUrl || "",
      category: req.body.category || "general",
      startingPrice: Number(req.body.startingPrice),
      currentPrice: Number(req.body.startingPrice),
      seller: req.user._id,
      endsAt: new Date(req.body.endsAt)
    };
    const created = await Auction.create(payload);
    res.status(201).json(created);
  }
);

router.patch("/:id", requireAuth, requireRole(["seller", "admin"]), async (req, res) => {
  const auction = await Auction.findById(req.params.id);
  if (!auction) return res.status(404).json({ error: "Not found" });
  if (String(auction.seller) !== String(req.user._id) && req.user.role !== "admin")
    return res.status(403).json({ error: "Forbidden" });
  const allowed = ["title", "description", "imageUrl", "category", "endsAt", "status"];
  for (const k of allowed) if (k in req.body) auction[k] = req.body[k];
  await auction.save();
  res.json(auction);
});

router.delete("/:id", requireAuth, requireRole(["seller", "admin"]), async (req, res) => {
  const auction = await Auction.findById(req.params.id);
  if (!auction) return res.status(404).json({ error: "Not found" });
  if (String(auction.seller) !== String(req.user._id) && req.user.role !== "admin")
    return res.status(403).json({ error: "Forbidden" });
  await auction.deleteOne();
  res.json({ ok: true });
});

router.post("/:id/bids", requireAuth, async (req, res) => {
  const { amount } = req.body;
  const auction = await Auction.findById(req.params.id);
  if (!auction || auction.status !== "active") return res.status(400).json({ error: "Auction not active" });
  const min = Math.max(auction.currentPrice || auction.startingPrice, auction.startingPrice);
  if (Number(amount) <= min) return res.status(400).json({ error: "Bid too low" });
  auction.currentPrice = Number(amount);
  auction.bids.push({ user: req.user._id, amount: Number(amount) });
  await auction.save();
  if (ioRef) {
    ioRef.emit("bid:update", {
      auctionId: String(auction._id),
      highestBid: auction.currentPrice,
      highestBidder: String(req.user._id),
      bidCount: auction.bids.length
    });
  }
  res.json({ ok: true, currentPrice: auction.currentPrice });
});

// Simple scheduler endpoint to close ended auctions (call periodically with cron or uptime pinger)
router.post("/close-ended", async (req, res) => {
  const now = new Date();
  const toClose = await Auction.find({ status: "active", endsAt: { $lte: now } });
  for (const a of toClose) {
    a.status = "closed";
    await a.save();
    if (ioRef) ioRef.emit("auction:closed", { auctionId: String(a._id) });
  }
  res.json({ closed: toClose.length });
});

export default router;
