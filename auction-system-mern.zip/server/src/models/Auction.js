import mongoose from "mongoose";

const bidSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    amount: { type: Number, required: true }
  },
  { timestamps: true }
);

const auctionSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, default: "" },
    imageUrl: { type: String, default: "" },
    category: { type: String, default: "general" },
    startingPrice: { type: Number, required: true },
    currentPrice: { type: Number, default: 0 },
    seller: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    bids: [bidSchema],
    endsAt: { type: Date, required: true },
    status: { type: String, enum: ["active", "closed"], default: "active" }
  },
  { timestamps: true }
);

export default mongoose.model("Auction", auctionSchema);
