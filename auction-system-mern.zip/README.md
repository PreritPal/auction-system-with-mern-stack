# Auction System (MERN + Socket.IO)

A full‑stack auction platform with user auth, item listings, live bidding, and role‑based access. Built using **MongoDB, Express, React, Node**, and **Socket.IO**.

## Features

- Email/password authentication with JWT (login/register)
- Create, edit, and delete auction listings (seller)
- Upload images (local dev storage by default)
- Live bidding via Socket.IO (real‑time highest bid updates)
- Countdown timers for auctions with automatic close
- Watchlist and search/filter by category/status
- Basic admin endpoints to view users/auctions
- Secure routes with role‑based guards (user/seller/admin)
- REST API with simple pagination & validation
- Ready for Docker (`docker-compose up`) and local dev
- Clean React UI (Vite + Tailwind) with React Router

## Project Structure

```
auction-system-mern/
├─ server/                # Express API + Socket.IO
├─ client/                # React web app (Vite + Tailwind)
├─ docker-compose.yml
├─ README.md
└─ LICENSE
```

## Quickstart (Local Dev)

### 1) Prereqs
- Node 18+ and npm
- MongoDB running locally (or use `docker-compose`)
- (Optional) Docker Desktop if you want to use containers

### 2) Environment Variables
Copy `.env.example` to `.env` in the server and fill values:
```
cd server
cp .env.example .env
```

### 3) Install & Run
**Server**
```
cd server
npm install
npm run dev
```
**Client**
```
cd client
npm install
npm run dev
```

The client dev server defaults to `http://localhost:5173` and proxies API calls to `http://localhost:4000` (configure in `client/vite.config.js` if needed).

### 4) Docker (Optional)
```
docker-compose up --build
```
Then open the client at `http://localhost:5173`.

## Default Accounts
After first run, you can register a new account from the UI. To promote a user to seller/admin, you can update in MongoDB directly (see `role` field in `User` document).

## API Overview

- `POST /api/auth/register` – create account
- `POST /api/auth/login` – issue JWT
- `GET /api/auctions` – list auctions
- `POST /api/auctions` – create auction (seller)
- `GET /api/auctions/:id` – auction detail
- `PATCH /api/auctions/:id` – update (seller)
- `DELETE /api/auctions/:id` – delete (seller)
- `POST /api/auctions/:id/bids` – place bid (auth)
- `GET /api/me` – profile

## Socket Events

- **Server -> Clients**
  - `bid:update` – { auctionId, highestBid, highestBidder, bidCount }
  - `auction:closed` – { auctionId, winner, finalPrice }

- **Client -> Server**
  - `bid:place` – { auctionId, amount, token }

## Scripts

- `server`: `npm run dev` uses nodemon
- `client`: `npm run dev` launches Vite

## Testing Notes

This is a teaching/demo project with minimal tests. Add tests as you extend features. Security hardening (e.g., CSRF on cookies, input sanitization, production image storage) is simplified for clarity.

## License

MIT
